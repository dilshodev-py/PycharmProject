from projects.PointOfSale.app.ui import UI

UI().main()