from aiogram import Router

order_router = Router()