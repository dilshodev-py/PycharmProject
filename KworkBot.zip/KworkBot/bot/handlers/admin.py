from aiogram import Router

admin_router = Router()

