from aiogram import Router

employee_router = Router()