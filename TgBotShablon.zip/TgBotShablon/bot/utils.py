

def send_order_to_employee():
    pass